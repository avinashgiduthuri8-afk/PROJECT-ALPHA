---
description: Engineering standards, architecture, workflows, and PAES
  documentation for designing, building, testing, deploying, and
  maintaining the PROJECT ALPHA AI trading platform.
name: PROJECT ALPHA
---

# PROJECT ALPHA

## Overview

Use this skill whenever working on PROJECT ALPHA architecture, scanner,
trading bots, risk engine, execution engine, deployment, monitoring,
documentation, or related engineering tasks.

## Core Rules

-   Scanner is the Single Source of Truth.
-   Trading Bots execute only Scanner signals.
-   Risk Engine approves every trade.
-   Execution Engine is the only component that places exchange orders.
-   Preserve modular architecture.
-   Follow PAES documents before introducing changes.

## Resources

Consult the files in the resources directory for detailed
specifications.
