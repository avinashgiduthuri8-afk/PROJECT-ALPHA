# Strategy Template
