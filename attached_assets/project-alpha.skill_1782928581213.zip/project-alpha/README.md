# PROJECT ALPHA Claude Skill

This package follows Anthropic's Claude Skill format.

Structure: - skill.md (entry point) - resources/ (PAES documents) -
templates/ - examples/ - scripts/
