# PAES-003

# ARCHITECTURE.md

Version: PAES v1.0.0

Status: Approved

Document Type:
Architecture Specification

Priority:
CRITICAL

This document defines the official architecture of PROJECT ALPHA.

All future development must comply with this architecture unless explicitly approved by the project owner.

---

# ARCHITECTURE PHILOSOPHY

PROJECT ALPHA follows a centralized intelligence architecture.

Market intelligence exists only once.

Trade execution exists only once.

Risk validation exists only once.

Every component has a single responsibility.

No duplicated business logic is permitted.

---

# SYSTEM OVERVIEW

Exchange APIs

↓

Market Intelligence Engine (Scanner)

↓

Signal Distribution Layer

↓

Strategy Execution Layer

↓

Risk Validation Layer

↓

Execution Layer

↓

Storage Layer

↓

Presentation Layer

↓

Communication Layer

---

# COMPLETE DATA FLOW

Exchange APIs

↓

Scanner

↓

Market Analysis

↓

Indicator Calculation

↓

Signal Generation

↓

Signal Validation

↓

Signal Distribution

↓

Trading Bot

↓

Strategy Validation

↓

Risk Engine

↓

Position Validation

↓

Execution Engine

↓

Trade Journal

↓

Dashboard

↓

Telegram

---

# LAYER DEFINITIONS

## Layer 1 — Exchange Layer

Responsibilities

• Market Data

• Price Data

• Volume

• Candles

• Order Book

• Account Information

This layer never performs analysis.

---

## Layer 2 — Scanner Engine

This is the Brain.

Responsibilities

Collect market data.

Calculate indicators.

Determine market state.

Generate opportunities.

Rank signals.

Maintain the only watchlist.

Publish strategy-specific signals.

Scanner owns ALL market intelligence.

No other module performs these tasks.

---

## Layer 3 — Signal Distribution

Responsibilities

Receive scanner signals.

Route signals.

Maintain delivery reliability.

Prevent duplicate signal delivery.

Support future strategies.

This layer contains no trading logic.

---

## Layer 4 — Strategy Execution

Each strategy is independent.

Examples

VGX

MTB

PMB

Responsibilities

Receive scanner signals.

Validate strategy rules.

Generate trade decisions.

Manage active positions.

Strategies never scan markets.

Strategies never own watchlists.

---

## Layer 5 — Risk Engine

Risk Engine is mandatory.

Every trade passes through Risk.

Responsibilities

Capital allocation.

Position sizing.

Maximum exposure.

Daily limits.

Emergency stop.

Portfolio validation.

Trade approval.

Only Risk Engine may reject a trade.

---

## Layer 6 — Execution Engine

Responsibilities

Paper Trading

Live Trading

Order placement

Order cancellation

Order updates

Trade journal creation

Execution Engine never decides WHICH trade to take.

---

## Layer 7 — Storage

Responsibilities

Trade history

Configuration

Analytics

Signal history

Logs

Recovery

Backups

Storage contains no business logic.

---

## Layer 8 — Dashboard

Responsibilities

Display information.

Portfolio visualization.

Charts.

Performance.

Status.

Dashboard never executes trades.

Dashboard never changes market state.

---

## Layer 9 — Telegram

Responsibilities

Commands

Notifications

Reports

Alerts

Telegram never contains trading logic.

---

# MODULE DEPENDENCIES

Exchange

↓

Scanner

↓

Signal Bus

↓

Trading Bots

↓

Risk Engine

↓

Execution

↓

Storage

↓

Dashboard

↓

Telegram

No module may skip layers.

---

# SCANNER OWNERSHIP

Scanner owns

Market Data

Indicators

Signal Scores

Market State

Watchlist

Signal Ranking

Scanner owns 100% of market intelligence.

---

# TRADING BOT OWNERSHIP

Trading Bots own

Entries

Exits

Position Management

Trailing Stops

Strategy Logic

Nothing else.

---

# RISK ENGINE OWNERSHIP

Risk Engine owns

Capital Allocation

Trade Approval

Position Size

Exposure Limits

Emergency Stop

Risk Score

---

# DESIGN PRINCIPLES

Single Responsibility

Loose Coupling

High Cohesion

Scalability

Maintainability

Reliability

Production First

---

# FORBIDDEN ARCHITECTURE

The following are prohibited:

❌ Market scanning inside trading bots.

❌ Multiple watchlists.

❌ Duplicate indicators.

❌ Duplicate risk calculations.

❌ Business logic inside Dashboard.

❌ Business logic inside Telegram.

❌ Direct exchange access from Dashboard.

❌ Direct execution without Risk Engine.

---

# FUTURE EXPANSION

Architecture must support

Unlimited strategies.

Unlimited exchanges.

Portfolio AI.

Machine Learning.

Institutional deployment.

Microservices.

Distributed execution.

No architectural redesign should be required.

---

# ARCHITECTURE GOAL

One Brain.

Many Strategies.

One Risk Engine.

One Execution Engine.

Unlimited Expansion.

---

END OF PAES-003