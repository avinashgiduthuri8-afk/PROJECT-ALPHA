# PURPOSE

Defines the communication protocol between Scanner and Trading Bots.

Every signal follows the same format.

---

# SIGNAL STRUCTURE

Signal ID

Timestamp

Exchange

Asset

Strategy

Market State

Signal Score

Confidence

Entry

Stop

Target

Risk

Metadata

---

# SIGNAL FLOW

Scanner

↓

Signal Bus

↓

Trading Bot

↓

Risk Engine

↓

Execution

---

# SIGNAL STATES

Generated

Validated

Published

Received

Accepted

Rejected

Executed

Closed

Archived

---

# RULES

Signals are immutable.

Each Signal ID is unique.

Signals expire after configured time.

Rejected signals remain in history.

---

# FUTURE

AI Confidence

Multi-strategy signals

Cross-exchange signals

Signal compression

END