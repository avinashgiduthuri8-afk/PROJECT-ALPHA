# PURPOSE

Telegram is the communication interface.

It sends information.

It receives commands.

It never performs business logic.

---

# RESPONSIBILITIES

Alerts

Commands

Reports

Status

Notifications

Health Alerts

Emergency Alerts

---

# COMMANDS

/status

/dashboard

/signals

/portfolio

/open

/closed

/risk

/scanner

/vgx

/mtb

/pmb

/help

---

# ALERTS

Signal Alerts

Trade Open

Trade Close

Stop Loss

Take Profit

Emergency

Scanner Offline

Exchange Offline

Risk Reject

Daily Summary

Weekly Summary

---

# RULES

Telegram never executes strategy logic.

Telegram never scans markets.

Telegram only communicates.

---

# FUTURE

Interactive menus

Charts

Voice

AI summaries

END