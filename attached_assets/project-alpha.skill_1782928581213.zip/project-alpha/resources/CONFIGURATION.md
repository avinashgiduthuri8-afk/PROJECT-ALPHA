# PURPOSE

Centralized configuration management.

Every module loads configuration from here.

---

# CONFIGURATION

Scanner

Bots

Risk

Execution

Dashboard

Telegram

Storage

Logging

Monitoring

Deployment

---

# PRINCIPLES

Single source of configuration.

Environment variables for secrets.

Validation before startup.

Defaults where appropriate.

---

# VALIDATION

Missing values

Invalid values

Conflicts

Duplicate keys

Unsupported options

---

# RULES

No hard-coded values.

No duplicated configuration.

Configuration changes must be logged.

---

# FUTURE

Configuration profiles

Remote configuration

Encrypted secrets

END