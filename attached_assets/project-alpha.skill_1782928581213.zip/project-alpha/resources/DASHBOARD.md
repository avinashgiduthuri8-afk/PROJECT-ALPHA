# PURPOSE

Dashboard is the visualization layer of PROJECT ALPHA.

It displays information.

It never executes trades.

It never performs market analysis.

---

# RESPONSIBILITIES

Display

• Portfolio

• Open Positions

• Closed Positions

• Scanner Status

• Trading Bot Status

• Risk Status

• Performance

• Logs

• Health

---

# PANELS

Market Overview

Scanner

Signals

VGX

MTB

PMB

Portfolio

Risk

Analytics

Performance

Health

Settings

---

# LIVE COMPONENTS

Signal Feed

Portfolio Value

PnL

Market State

Open Trades

Closed Trades

Bot Status

Risk Status

CPU

Memory

API Health

---

# RULES

Dashboard is read-only.

Dashboard never changes market state.

Dashboard never executes trades.

Dashboard never bypasses Scanner.

Dashboard never bypasses Risk Engine.

---

# REFRESH

Scanner

5 sec

Bots

2 sec

Portfolio

2 sec

Health

5 sec

Analytics

30 sec

---

# FUTURE

Multi Dashboard

Mobile Dashboard

Web Dashboard

Desktop Dashboard

AI Insights

Custom Widgets

END