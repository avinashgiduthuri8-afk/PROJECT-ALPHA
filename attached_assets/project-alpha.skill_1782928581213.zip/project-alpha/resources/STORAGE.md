# PURPOSE

Storage is responsible for persistence.

Nothing else.

---

# STORES

Configuration

Trades

Signals

Logs

Analytics

Performance

Portfolio

History

Backups

---

# RESPONSIBILITIES

Read

Write

Backup

Recovery

Integrity

Migration

---

# RULES

Atomic writes

No business logic

Automatic backups

Data validation

Recovery support

---

# FUTURE

SQLite

PostgreSQL

Redis

Cloud Storage

Data Warehouse

END