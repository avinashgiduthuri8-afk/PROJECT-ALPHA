# PAES-007

# AI_DEVELOPMENT_RULES.md

Version: PAES v1.0

Status: Active

---

# PURPOSE

Define how AI systems (Claude, ChatGPT, Codex, Gemini, etc.) should contribute to PROJECT ALPHA.

These rules ensure consistent, production-quality development.

---

# PRIMARY OBJECTIVE

Every AI-generated change should improve the project without degrading architecture, reliability, or maintainability.

---

# BEFORE WRITING CODE

Understand the task.

Review existing architecture.

Identify affected modules.

Determine dependencies.

Check compatibility.

Avoid unnecessary rewrites.

---

# DURING IMPLEMENTATION

Preserve modularity.

Reuse existing components.

Avoid duplicate logic.

Follow coding standards.

Maintain backward compatibility.

Implement complete solutions.

Never leave placeholders.

---

# AFTER IMPLEMENTATION

Verify architecture.

Review dependencies.

Update documentation.

Update version history.

Confirm configuration.

Recommend testing.

---

# ARCHITECTURE RULES

AI must never

Duplicate Scanner logic

Duplicate Risk logic

Duplicate Watchlists

Move business logic into Dashboard

Move business logic into Telegram

Bypass Risk Engine

Bypass Scanner

---

# MODIFICATION RULES

Prefer extending existing modules.

Avoid replacing working systems without justification.

Large refactors require explanation.

Breaking changes require approval.

---

# DOCUMENTATION RULES

Every significant change should update

Architecture

Version Information

Relevant Module Specification

Release Notes

---

# CODE QUALITY RULES

Generate production-ready code.

No TODOs.

No FIXME markers.

No placeholder implementations.

No incomplete methods.

No commented-out code.

---

# DECISION PRIORITY

Security

↓

Reliability

↓

Architecture

↓

Maintainability

↓

Scalability

↓

Performance

↓

Features

---

# WHEN UNCERTAIN

AI should

Ask for clarification rather than guessing.

Explain assumptions.

Present trade-offs.

Avoid inventing undocumented requirements.

---

# FUTURE COMPATIBILITY

Every implementation should support

New exchanges

New strategies

New dashboards

Additional AI agents

Microservices

Future scaling

without requiring major redesign.

---

# FINAL PRINCIPLE

AI is an engineering assistant.

It must strengthen PROJECT ALPHA, not merely generate code.

Every contribution should leave the codebase cleaner, more consistent, and easier to maintain.

---

END OF DOCUMENT